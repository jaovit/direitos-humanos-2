 var titulo =  document.getElementById("titulo");
 var propriedades = titulo.getBoundingClientRect();
 var largura = propriedades.width
  console.log(largura)
largura = (largura /2) - largura
console.log(largura)

 titulo.style.marginLeft = largura +"px"

var opa = propriedades.width
 console.log(opa)